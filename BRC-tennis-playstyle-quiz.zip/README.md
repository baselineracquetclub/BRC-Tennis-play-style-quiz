# BRC Tennis Play-Style Quiz

Single-page web quiz for Baseline Racquet Club.  

**Usage:** Open `index.html` locally or host via GitHub Pages.

Features:
- 15-question multi-step quiz
- Determines primary tennis play style
- Bold & sporty design
